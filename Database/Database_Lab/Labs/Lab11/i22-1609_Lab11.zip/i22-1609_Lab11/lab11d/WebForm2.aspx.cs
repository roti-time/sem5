﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace lab11d
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=lab11d;Integrated Security=True;");
            conn.Open();
            SqlCommand cm;

            string id = TextBox1.Text;
            string st = TextBox2.Text;

            // Cast both carid (ntext) and the parameter to nvarchar(max) for comparison
            string query = "UPDATE table1 SET status = @status WHERE CAST(Car_ID AS NVARCHAR(MAX)) = CAST(@Car_ID AS NVARCHAR(MAX))";

            cm = new SqlCommand(query, conn);

            // Define the parameters explicitly as ntext
            cm.Parameters.Add(new SqlParameter("@Status", System.Data.SqlDbType.NText) { Value = st });
            cm.Parameters.Add(new SqlParameter("@Car_ID", System.Data.SqlDbType.NText) { Value = id });

            cm.ExecuteNonQuery();

            cm.Dispose();
            conn.Close();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}