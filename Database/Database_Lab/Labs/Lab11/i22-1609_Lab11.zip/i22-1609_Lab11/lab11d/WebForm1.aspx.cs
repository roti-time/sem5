﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace lab11d
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=lab11d;Integrated Security=True;");
            conn.Open();
            SqlCommand cm;
            string un = TextBox1.Text;
            string pass = TextBox2.Text;
            string st = TextBox3.Text;
            string id=TextBox4.Text;
            string query = "Insert into table1(Car_ID,Make, Model,Status) values ('" + id + "','" + un + "','" + pass + "','" + st + "')";
            cm = new SqlCommand(query, conn);
            cm.ExecuteNonQuery();
            cm.Dispose();
            conn.Close();
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}